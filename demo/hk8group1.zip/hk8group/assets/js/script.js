// SCRIPTS: menu toggle, auto-close, reveal on scroll, basic form simulation
// Menu toggle (burger -> X and mobile menu slide)
const burger = document.getElementById("burger");
const mobileMenu = document.getElementById("mobileMenu");
burger.addEventListener("click", () => {
  burger.classList.toggle("is-active");
  mobileMenu.classList.toggle("is-active");

  // lock/unlock body scrolling when menu open/close
  const isOpen = mobileMenu.classList.contains("is-active");
  document.body.style.overflow = isOpen ? "hidden" : "";
  document.body.style.touchAction = isOpen ? "none" : "";

  // reflect accessibility states
  mobileMenu.setAttribute("aria-hidden", isOpen ? "false" : "true");
  burger.setAttribute("aria-expanded", isOpen ? "true" : "false");
});

// Close mobile menu when link clicked
document
  .querySelectorAll(".mobile-menu .menu-inner a, .menu a")
  .forEach((a) => {
    a.addEventListener("click", () => {
      // if mobile menu open, close it
      if (mobileMenu.classList.contains("is-active")) {
        mobileMenu.classList.remove("is-active");
        burger.classList.remove("is-active");
        document.body.style.overflow = "";
        document.body.style.touchAction = "";
        mobileMenu.setAttribute("aria-hidden", "true");
        burger.setAttribute("aria-expanded", "false");
      }
    });
  });

// Close with Escape key for better UX
window.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && mobileMenu.classList.contains("is-active")) {
    mobileMenu.classList.remove("is-active");
    burger.classList.remove("is-active");
    document.body.style.overflow = "";
    document.body.style.touchAction = "";
    mobileMenu.setAttribute("aria-hidden", "true");
    burger.setAttribute("aria-expanded", "false");
  }
});

// IntersectionObserver to reveal elements
const reveals = document.querySelectorAll(".reveal");
const obs = new IntersectionObserver(
  (entries, o) => {
    entries.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add("show");
        o.unobserve(e.target);
      }
    });
  },
  { threshold: 0.15 }
);
reveals.forEach((el) => obs.observe(el));

// Contact form basic simulation (no backend)
const form = document.getElementById("contactForm");
const formMsg = document.getElementById("formMsg");
if (form) {
  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    // simple feedback
    formMsg.textContent = "Pesan terkirim — terima kasih!";
    setTimeout(() => (formMsg.textContent = ""), 4500);
    form.reset();
  });
}

// Ensure smooth closing when resizing to desktop
window.addEventListener("resize", () => {
  if (window.innerWidth >= 768) {
    mobileMenu.classList.remove("is-active");
    burger.classList.remove("is-active");
    document.body.style.overflow = "";
    document.body.style.touchAction = "";
    mobileMenu.setAttribute("aria-hidden", "true");
    burger.setAttribute("aria-expanded", "false");
  }
});
